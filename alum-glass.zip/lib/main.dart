import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'logo_data.dart';

late SharedPreferences prefs;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  prefs = await SharedPreferences.getInstance();
  runApp(const App());
}

// ---------- الإعدادات (كلها قابلة للتعديل) ----------
const Map<String, List<dynamic>> settingDefs = {
  'win_kaab_mm': ['الشباك: ناقص من العرض للكعب (ملم)', 20.5],
  'win_h': ['الشباك: ناقص من الارتفاع للمسكة+الشنكل (سم)', 4.0],
  'win_gw': ['الشباك: زائد على الكعب لعرض الزجاج (سم)', 1.5],
  'win_gl': ['الشباك: ناقص من طول الدرفة لطول الزجاج (سم)', 10.6],
  'door_kaab': ['الباب: ناقص من العرض لعرض الدرفة (سم)', 3.6],
  'door_h': ['الباب: ناقص من الارتفاع لطول الدرفة (سم)', 2.8],
  'door_gw': ['الباب: ناقص من عرض الدرفة لعرض الزجاج (سم)', 11.5],
  'door_gl': ['الباب: ناقص من طول الباب لطول الزجاج (سم)', 15.0],
  'disc': ['سماكة الديسك (ملم)', 4.0],
  'bar_len': ['طول القضيب الخام (سم)', 595.0],
  'panel_w': ['عرض اللوح الخام (سم)', 122.0],
  'panel_h': ['طول اللوح الخام (سم)', 244.0],
};

double setting(String k) => prefs.getDouble('s_$k') ?? (settingDefs[k]![1] as double);

String f(double v) {
  var s = v.toStringAsFixed(2);
  if (s.contains('.')) {
    s = s.replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');
  }
  return s;
}

double? num_(String s) => double.tryParse(s.trim().replaceAll(',', '.'));

const Color gold = Color(0xFFFFC107);
const Color navy = Color(0xFF0D2A4A);
const Color logoBg = Color(0xFFF5F5F0);

AppBar bar(String t) => AppBar(title: Text(t), backgroundColor: navy, foregroundColor: Colors.white);

List<List<double>> decodeRows(String? s) {
  if (s == null) return [];
  return (jsonDecode(s) as List).map((e) => (e as List).map((x) => (x as num).toDouble()).toList()).toList();
}

// ---------- الأنواع (شباك، باب، وأنواع يضيفها المستخدم) ----------
class Kind {
  final String id, title;
  final int glassMult;
  // كل سطر: [الاسم, القيمة]، وآخر سطرين هما عرض وطول الزجاج
  final List<List<dynamic>> Function(double w, double h) calc;
  const Kind(this.id, this.title, this.glassMult, this.calc);
}

final Kind windowKind = Kind('win', 'الشبابيك', 2, (w, h) {
  final kaab = (w - setting('win_kaab_mm') / 10) / 2;
  final masika = h - setting('win_h');
  return [
    ['الكعب', kaab],
    ['المسكة+الشنكل', masika],
    ['عرض الزجاج', kaab + setting('win_gw')],
    ['طول الزجاج', masika - setting('win_gl')],
  ];
});

final Kind doorKind = Kind('door', 'الأبواب', 1, (w, h) {
  final sw = w - setting('door_kaab');
  final sl = h - setting('door_h');
  return [
    ['عرض الدرفة', sw],
    ['طول الدرفة', sl],
    ['عرض الزجاج', sw - setting('door_gw')],
    ['طول الزجاج', h - setting('door_gl')],
  ];
});

List<Map<String, dynamic>> loadTypes() {
  final s = prefs.getString('custom_types');
  if (s == null) return [];
  return (jsonDecode(s) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
}

void saveTypes(List<Map<String, dynamic>> t) => prefs.setString('custom_types', jsonEncode(t));

Kind kindFromType(Map<String, dynamic> t) {
  final a = (t['a'] as num).toDouble();
  final div = (t['div'] as num).toDouble();
  final b = (t['b'] as num).toDouble();
  final c = (t['c'] as num).toDouble();
  final d = (t['d'] as num).toDouble();
  return Kind('c_${t['id']}', t['name'] as String, div.round() < 1 ? 1 : div.round(), (w, h) {
    final sw = (w - a) / div;
    final sl = h - b;
    return [
      ['عرض الدرفة', sw],
      ['طول الدرفة', sl],
      ['عرض الزجاج', sw + c],
      ['طول الزجاج', sl - d],
    ];
  });
}

Widget itemsPage(Kind k) => RowsPage(
      title: 'إدخال ${k.title}',
      storeKey: 'items_${k.id}',
      cols: const ['العرض (سم)', 'الارتفاع (سم)', 'العدد'],
      results: (v) => ItemsResults(kind: k, items: v),
    );

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WD Alu Glass',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: navy)),
      builder: (c, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const Home(),
    );
  }
}

// ---------- الواجهة الرئيسية ----------
class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Widget tile(String title, IconData icon, Color color, Widget Function() page) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: Material(
          color: color,
          borderRadius: BorderRadius.circular(18),
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page())),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 52, color: Colors.white),
                const SizedBox(height: 8),
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasCustom = loadTypes().isNotEmpty;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              color: logoBg,
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Image.memory(logoBytes, height: 170, fit: BoxFit.contain),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Column(
                  children: [
                    Expanded(
                      child: Row(children: [
                        tile('الشبابيك', Icons.window, const Color(0xFF1E73BE), () => itemsPage(windowKind)),
                        tile('الباب', Icons.door_front_door, const Color(0xFF2AA7B8), () => itemsPage(doorKind)),
                      ]),
                    ),
                    Expanded(
                      child: Row(children: [
                        tile('حساب الألواح', Icons.grid_view, const Color(0xFF1E73BE), () => panelsPage()),
                        tile('حساب القضبان', Icons.straighten, const Color(0xFF2AA7B8), () => barsPage()),
                      ]),
                    ),
                  ],
                ),
              ),
            ),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 8,
              children: [
                TextButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TotalPage())),
                  icon: const Icon(Icons.functions),
                  label: const Text('الإجمالي الكلي'),
                ),
                if (hasCustom)
                  TextButton.icon(
                    onPressed: () =>
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomListPage())),
                    icon: const Icon(Icons.apps),
                    label: const Text('أنواع أخرى'),
                  ),
                TextButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage()))
                      .then((_) => setState(() {})),
                  icon: const Icon(Icons.settings),
                  label: const Text('إعدادات الخصميات'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class CustomListPage extends StatelessWidget {
  const CustomListPage({super.key});
  @override
  Widget build(BuildContext context) {
    final types = loadTypes();
    return Scaffold(
      appBar: bar('أنواع أخرى'),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          for (final t in types)
            Card(
              child: ListTile(
                title: Text(t['name'] as String, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                trailing: const Icon(Icons.arrow_back_ios_new),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => itemsPage(kindFromType(t)))),
              ),
            ),
        ],
      ),
    );
  }
}

// ---------- صفحة إدخال بسطور على كامل الصفحة (عامة) ----------
class RowsPage extends StatefulWidget {
  final String title, storeKey;
  final List<String> cols; // آخر عمود هو العدد
  final Widget Function(List<List<double>> rows) results;
  const RowsPage({super.key, required this.title, required this.storeKey, required this.cols, required this.results});
  @override
  State<RowsPage> createState() => _RowsPageState();
}

class _RowsPageState extends State<RowsPage> {
  final List<List<TextEditingController>> rows = [];
  int get n => widget.cols.length;

  List<TextEditingController> newRow([List<double>? v]) => List.generate(
      n, (i) => TextEditingController(text: v != null ? f(v[i]) : (i == n - 1 ? '1' : '')));

  @override
  void initState() {
    super.initState();
    for (final l in decodeRows(prefs.getString(widget.storeKey))) {
      if (l.length == n) rows.add(newRow(l));
    }
    while (rows.length < 5) {
      rows.add(newRow());
    }
  }

  List<List<double>> valid() {
    final out = <List<double>>[];
    for (final r in rows) {
      final v = r.map((c) => num_(c.text)).toList();
      if (v.every((e) => e != null && e > 0)) out.add(v.cast<double>());
    }
    return out;
  }

  void save() => prefs.setString(widget.storeKey, jsonEncode(valid()));

  @override
  Widget build(BuildContext context) {
    const kb = TextInputType.numberWithOptions(decimal: true);
    const d = InputDecoration(border: OutlineInputBorder(), isDense: true);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: navy,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
              tooltip: 'مسح الكل',
              icon: const Icon(Icons.delete_sweep),
              onPressed: () => setState(() {
                    rows.clear();
                    for (int i = 0; i < 5; i++) {
                      rows.add(newRow());
                    }
                    save();
                  })),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
            child: Row(children: [
              const SizedBox(width: 30),
              for (int i = 0; i < n; i++)
                i == n - 1
                    ? SizedBox(width: 70, child: Center(child: Text(widget.cols[i], style: const TextStyle(fontWeight: FontWeight.bold))))
                    : Expanded(child: Center(child: Text(widget.cols[i], style: const TextStyle(fontWeight: FontWeight.bold)))),
              const SizedBox(width: 40),
            ]),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: rows.length,
              itemBuilder: (c, i) {
                final r = rows[i];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(children: [
                    SizedBox(width: 30, child: Text('${i + 1}', textAlign: TextAlign.center)),
                    for (int j = 0; j < n; j++)
                      j == n - 1
                          ? SizedBox(
                              width: 70,
                              child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 3),
                                  child: TextField(controller: r[j], keyboardType: kb, decoration: d, onChanged: (_) => save())))
                          : Expanded(
                              child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 3),
                                  child: TextField(controller: r[j], keyboardType: kb, decoration: d, onChanged: (_) => save()))),
                    SizedBox(
                        width: 40,
                        child: IconButton(
                            padding: EdgeInsets.zero,
                            icon: const Icon(Icons.close, color: Colors.red),
                            onPressed: () => setState(() {
                                  rows.removeAt(i);
                                  if (rows.isEmpty) rows.add(newRow());
                                  save();
                                }))),
                  ]),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(
                  child: OutlinedButton.icon(
                      onPressed: () => setState(() => rows.add(newRow())),
                      icon: const Icon(Icons.add),
                      label: const Text('إضافة سطر'))),
              const SizedBox(width: 8),
              Expanded(
                  flex: 2,
                  child: FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: navy, padding: const EdgeInsets.symmetric(vertical: 14)),
                      onPressed: () {
                        final v = valid();
                        if (v.isEmpty) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل سطراً واحداً على الأقل')));
                          return;
                        }
                        save();
                        Navigator.push(context, MaterialPageRoute(builder: (_) => widget.results(v)));
                      },
                      icon: const Icon(Icons.calculate),
                      label: const Text('احسب وأظهر النتائج', style: TextStyle(fontSize: 16)))),
            ]),
          ),
        ],
      ),
    );
  }
}

Widget footer(String t) => Container(
      width: double.infinity,
      color: navy,
      padding: const EdgeInsets.all(12),
      child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: gold, fontWeight: FontWeight.bold)),
    );

Widget bigBoxes(List<List<String>> items) => Container(
      color: navy,
      padding: const EdgeInsets.all(8),
      child: Row(
        children: [
          for (final e in items)
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(4),
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
                child: Column(children: [
                  Text(e[0], textAlign: TextAlign.center, style: const TextStyle(fontSize: 13)),
                  const SizedBox(height: 4),
                  Text(e[1], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: navy)),
                ]),
              ),
            ),
        ],
      ),
    );

double areaOf(List<List<double>> rows) {
  double a = 0;
  for (final it in rows) {
    a += it[0] * it[1] / 10000 * it[2];
  }
  return a;
}

double glassOf(Kind k, List<List<double>> rows) {
  double g = 0;
  for (final it in rows) {
    final r = k.calc(it[0], it[1]);
    g += (r[2][1] as double) * (r[3][1] as double) / 10000 * it[2] * k.glassMult;
  }
  return g;
}

// ---------- الإجمالي الكلي (الشبابيك والأنواع الإضافية، بدون الأبواب) ----------
class TotalPage extends StatelessWidget {
  const TotalPage({super.key});
  @override
  Widget build(BuildContext context) {
    final kinds = <Kind>[windowKind, ...loadTypes().map(kindFromType)];
    double ta = 0, tg = 0;
    final cards = <Widget>[];
    for (final k in kinds) {
      final rows = decodeRows(prefs.getString('items_${k.id}')).where((e) => e.length == 3).toList();
      final a = areaOf(rows), g = glassOf(k, rows);
      ta += a;
      tg += g;
      cards.add(Card(
        child: ListTile(
          title: Text('${k.title}  (${rows.length} سطر)', style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('المساحة: ${f(a)} م²   |   الزجاج: ${f(g)} م²'),
        ),
      ));
    }
    return Scaffold(
      appBar: bar('الإجمالي الكلي'),
      body: Column(
        children: [
          Expanded(child: ListView(padding: const EdgeInsets.all(8), children: cards)),
          bigBoxes([
            ['مساحة الشبابيك الكلية', '${f(ta)} م²'],
            ['مساحة الزجاج الكلية', '${f(tg)} م²'],
          ]),
        ],
      ),
    );
  }
}

// ---------- نتائج الشبابيك والأبواب ----------
class ItemsResults extends StatelessWidget {
  final Kind kind;
  final List<List<double>> items;
  const ItemsResults({super.key, required this.kind, required this.items});

  @override
  Widget build(BuildContext context) {
    double totalArea = 0, totalGlass = 0;
    int totalCount = 0;
    for (final it in items) {
      final r = kind.calc(it[0], it[1]);
      totalArea += it[0] * it[1] / 10000 * it[2];
      totalGlass += (r[2][1] as double) * (r[3][1] as double) / 10000 * it[2] * kind.glassMult;
      totalCount += it[2].round();
    }
    return Scaffold(
      appBar: bar('النتائج'),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: items.length,
              itemBuilder: (c, i) {
                final it = items[i];
                final r = kind.calc(it[0], it[1]);
                final lines = r.map((e) => '${e[0]}: ${f(e[1] as double)}').join('\n');
                return Card(
                  child: ListTile(
                    title: Text('${i + 1}:  ${f(it[0])} × ${f(it[1])}   (عدد ${f(it[2])})',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('$lines\nالمساحة: ${f(it[0] * it[1] / 10000 * it[2])} م²'),
                    isThreeLine: true,
                  ),
                );
              },
            ),
          ),
          bigBoxes([
            ['العدد', '$totalCount'],
            ['المساحة', '${f(totalArea)} م²'],
            ['الزجاج', '${f(totalGlass)} م²'],
          ]),
        ],
      ),
    );
  }
}

// ---------- حساب القضبان ----------
Widget barsPage() => RowsPage(
      title: 'إدخال القضبان',
      storeKey: 'pieces_bars',
      cols: const ['الطول (سم)', 'العدد'],
      results: (v) => BarsResults(pieces: v),
    );

class BarsResults extends StatelessWidget {
  final List<List<double>> pieces;
  const BarsResults({super.key, required this.pieces});

  @override
  Widget build(BuildContext context) {
    final barLen = setting('bar_len');
    final kerf = setting('disc') / 10;
    final all = <double>[];
    String? err;
    for (final p in pieces) {
      if (p[0] > barLen) err = 'قطعة طولها ${f(p[0])} أطول من القضيب';
      for (int k = 0; k < p[1].round(); k++) {
        all.add(p[0]);
      }
    }
    all.sort((a, b) => b.compareTo(a));
    final bars = <List<double>>[];
    final rem = <double>[];
    if (err == null) {
      for (final len in all) {
        int idx = -1;
        for (int b = 0; b < bars.length; b++) {
          if (rem[b] >= len) {
            idx = b;
            break;
          }
        }
        if (idx == -1) {
          bars.add([]);
          rem.add(barLen);
          idx = bars.length - 1;
        }
        bars[idx].add(len);
        rem[idx] = (rem[idx] - len - kerf).clamp(0, double.infinity).toDouble();
      }
    }
    final totalWaste = rem.fold<double>(0, (a, b) => a + b);
    return Scaffold(
      appBar: bar('نتائج القضبان'),
      body: ListView(
        padding: const EdgeInsets.all(8),
        children: [
          Text('طول القضيب: ${f(barLen)} سم  |  الديسك: ${f(setting('disc'))} ملم', textAlign: TextAlign.center),
          const SizedBox(height: 6),
          if (err != null) Text(err, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          if (err == null) ...[
            Text('عدد القضبان: ${bars.length}   |   مجموع الهدر: ${f(totalWaste)} سم',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            for (int b = 0; b < bars.length; b++)
              Card(
                color: Colors.orange.shade50,
                child: ListTile(
                  title: Text('قضيب ${b + 1}: ${bars[b].map(f).join(' + ')}'),
                  subtitle: Text('الهدر: ${f(rem[b])} سم'),
                ),
              ),
          ],
        ],
      ),
    );
  }
}

// ---------- حساب الألواح ----------
Widget panelsPage() => RowsPage(
      title: 'إدخال الألواح',
      storeKey: 'pieces_panels',
      cols: const ['العرض (سم)', 'الطول (سم)', 'العدد'],
      results: (v) => PanelsResults(pieces: v),
    );

class SheetPainter extends CustomPainter {
  final double sw, sh, scale;
  final List<List<double>> pieces; // x, y, w, h
  final List<double> cutsY;
  SheetPainter(this.sw, this.sh, this.scale, this.pieces, this.cutsY);

  @override
  void paint(Canvas c, Size size) {
    c.drawRect(Rect.fromLTWH(0, 0, sw * scale, sh * scale), Paint()..color = const Color(0xFFEFEBE9));
    const colors = [Color(0xFF90CAF9), Color(0xFFA5D6A7), Color(0xFFFFE082), Color(0xFFCE93D8), Color(0xFFFFAB91)];
    for (int i = 0; i < pieces.length; i++) {
      final p = pieces[i];
      final r = Rect.fromLTWH(p[0] * scale, p[1] * scale, p[2] * scale, p[3] * scale);
      c.drawRect(r, Paint()..color = colors[i % colors.length]);
      c.drawRect(r, Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = Colors.black87);
      final tp = TextPainter(
        text: TextSpan(text: '${f(p[2])}×${f(p[3])}', style: const TextStyle(color: Colors.black, fontSize: 11)),
        textDirection: TextDirection.ltr,
      )..layout();
      if (tp.width < r.width - 2 && tp.height < r.height - 2) {
        tp.paint(c, Offset(r.left + (r.width - tp.width) / 2, r.top + (r.height - tp.height) / 2));
      }
    }
    for (final y in cutsY) {
      c.drawLine(Offset(0, y * scale), Offset(sw * scale, y * scale), Paint()
        ..color = Colors.red
        ..strokeWidth = 1.6);
    }
    c.drawRect(Rect.fromLTWH(0, 0, sw * scale, sh * scale), Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..color = Colors.black);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}

class PanelsResults extends StatelessWidget {
  final List<List<double>> pieces;
  const PanelsResults({super.key, required this.pieces});

  @override
  Widget build(BuildContext context) {
    final sw = setting('panel_w'), sh = setting('panel_h'), kerf = setting('disc') / 10;
    String? err;
    final all = <List<double>>[];
    for (final p in pieces) {
      if (p[0] > sw || p[1] > sh) err = 'قطعة ${f(p[0])}×${f(p[1])} أكبر من اللوح';
      for (int k = 0; k < p[2].round(); k++) {
        all.add([p[0], p[1]]);
      }
    }
    all.sort((a, b) => b[1].compareTo(a[1]));
    final sheets = <List<List<double>>>[]; // رفوف كل لوح: [y, ارتفاع الرف, العرض المستعمل]
    final placed = <List<List<double>>>[]; // قطع كل لوح: [x, y, w, h]
    double usedArea = 0;
    if (err == null) {
      for (final p in all) {
        final w = p[0] + kerf, h = p[1] + kerf;
        bool ok = false;
        for (int s = 0; s < sheets.length && !ok; s++) {
          for (final shelf in sheets[s]) {
            if (h <= shelf[1] && shelf[2] + w <= sw + kerf) {
              placed[s].add([shelf[2], shelf[0], p[0], p[1]]);
              shelf[2] += w;
              ok = true;
              break;
            }
          }
          if (!ok) {
            final y = sheets[s].isEmpty ? 0.0 : sheets[s].last[0] + sheets[s].last[1];
            if (y + h <= sh + kerf) {
              sheets[s].add([y, h, w]);
              placed[s].add([0.0, y, p[0], p[1]]);
              ok = true;
            }
          }
        }
        if (!ok) {
          sheets.add([
            [0.0, h, w]
          ]);
          placed.add([
            [0.0, 0.0, p[0], p[1]]
          ]);
        }
        usedArea += p[0] * p[1];
      }
    }
    final waste = sheets.isEmpty ? 0.0 : (1 - usedArea / (sheets.length * sw * sh)) * 100;
    return Scaffold(
      appBar: bar('نتائج الألواح'),
      body: ListView(
        padding: const EdgeInsets.all(8),
        children: [
          Text('اللوح: ${f(sw)} × ${f(sh)} سم  |  الديسك: ${f(setting('disc'))} ملم', textAlign: TextAlign.center),
          const SizedBox(height: 6),
          if (err != null) Text(err, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          if (err == null) ...[
            Text('عدد الألواح: ${sheets.length}   |   الهدر: ${f(waste)}%',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const Text('الخطوط الحمراء = القصات الأفقية الأولى، وحواف القطع = القصات العمودية',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
            for (int s = 0; s < sheets.length; s++)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('لوح ${s + 1}  (${placed[s].length} قطعة)',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 6),
                      LayoutBuilder(builder: (ctx, cons) {
                        final scale = cons.maxWidth / sw;
                        final cuts = <double>[
                          for (final sh2 in sheets[s])
                            if (sh2[0] + sh2[1] - kerf < sh - 0.01) sh2[0] + sh2[1] - kerf
                        ];
                        return SizedBox(
                          width: cons.maxWidth,
                          height: sh * scale,
                          child: CustomPaint(painter: SheetPainter(sw, sh, scale, placed[s], cuts)),
                        );
                      }),
                      const SizedBox(height: 8),
                      for (int k = 0; k < sheets[s].length; k++) ...[
                        Text('قص أفقي ${k + 1}: على بعد ${f(sheets[s][k][0] + sheets[s][k][1] - kerf)} سم من الأعلى',
                            style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text('ثم قص الشريط عمودياً إلى: ' +
                            placed[s].where((q) => q[1] == sheets[s][k][0]).map((q) => f(q[2])).join(' + ')),
                        const SizedBox(height: 4),
                      ],
                    ],
                  ),
                ),
              ),
          ],
        ],
      ),
    );
  }
}

// ---------- الإعدادات ----------
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final ctrls = <String, TextEditingController>{};
  List<Map<String, dynamic>> types = [];

  @override
  void initState() {
    super.initState();
    for (final k in settingDefs.keys) {
      ctrls[k] = TextEditingController(text: f(setting(k)));
    }
    types = loadTypes();
  }

  Future<void> editType(int? i) async {
    final old = i == null ? null : types[i];
    final labels = [
      'خصم من العرض (سم)',
      'قسمة الناتج على (مثلاً 2 لدرفتين)',
      'خصم من الارتفاع لطول الدرفة (سم)',
      'عرض الزجاج = عرض الدرفة + (سم، سالب للنقصان)',
      'طول الزجاج = طول الدرفة − (سم)',
    ];
    final keys = ['a', 'div', 'b', 'c', 'd'];
    final nameC = TextEditingController(text: old == null ? '' : old['name'] as String);
    final cs = [
      for (int j = 0; j < 5; j++)
        TextEditingController(text: old == null ? (j == 1 ? '1' : '') : f((old[keys[j]] as num).toDouble()))
    ];
    final res = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(old == null ? 'إضافة نوع جديد' : 'تعديل النوع'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: nameC, decoration: const InputDecoration(labelText: 'اسم النوع', border: OutlineInputBorder())),
            for (int j = 0; j < 5; j++)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: TextField(
                  controller: cs[j],
                  keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                  decoration: InputDecoration(labelText: labels[j], border: const OutlineInputBorder()),
                ),
              ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              final v = cs.map((e) => num_(e.text)).toList();
              if (nameC.text.trim().isEmpty || v.any((e) => e == null) || v[1]! < 1) return;
              Navigator.pop(ctx, <String, dynamic>{
                'id': old == null ? DateTime.now().millisecondsSinceEpoch.toString() : old['id'],
                'name': nameC.text.trim(),
                for (int j = 0; j < 5; j++) keys[j]: v[j],
              });
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    if (res == null) return;
    setState(() {
      if (i == null) {
        types.add(res);
      } else {
        types[i] = res;
      }
    });
    saveTypes(types);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: bar('إعدادات الخصميات'),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          for (final k in settingDefs.keys)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: TextField(
                controller: ctrls[k],
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: settingDefs[k]![0] as String, border: const OutlineInputBorder()),
                onChanged: (v) {
                  final n = num_(v);
                  if (n != null) prefs.setDouble('s_$k', n);
                },
              ),
            ),
          const Text('يتم الحفظ تلقائياً', textAlign: TextAlign.center),
          const Divider(height: 32),
          const Text('أنواع إضافية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          for (int i = 0; i < types.length; i++)
            Card(
              child: ListTile(
                title: Text(types[i]['name'] as String),
                onTap: () => editType(i),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    setState(() => types.removeAt(i));
                    saveTypes(types);
                  },
                ),
              ),
            ),
          const SizedBox(height: 8),
          FilledButton.icon(
              onPressed: () => editType(null), icon: const Icon(Icons.add), label: const Text('إضافة نوع جديد')),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
